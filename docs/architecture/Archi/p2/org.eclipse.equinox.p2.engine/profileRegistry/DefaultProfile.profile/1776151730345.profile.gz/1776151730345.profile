<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1776151730345'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/Users/phillipus/Desktop/ArchiBuild/projects.tmp/com.archimatetool.editor.product/target/products/com.archimatetool.editor.product/linux/gtk/x86_64/Archi'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_GB'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Users/phillipus/Desktop/ArchiBuild/projects.tmp/com.archimatetool.editor.product/target/products/com.archimatetool.editor.product/linux/gtk/x86_64/Archi'/>
  </properties>
</profile>
